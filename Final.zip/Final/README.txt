IFT6010 - Automatic summarizer
Lara Haidar et Ludovic Font


###########################
1. Lancement du programme :
###########################
Sur Unix : 
	java -jar Summarizer.jar [dir]
	ou dir doit indiquer un r�pertoire o� se trouvent config.txt, idf.txt, le dossier lib et le dossier Taggers. Par d�faut (sans argument), utilise le r�pertoire courant. 
Sur Windows : 
	ex�cuter Start.bat

####################
2. Fichiers requis :
####################
config.txt : peut contenir plusieurs lignes :
	file=[fichier] : indique que [fichier] contient un texte � r�sumer. Plusieurs lignes de ce type feront que le programme r�sumera tous les documents.
	abstractdestfile=[fichier] : le r�sum� par abstraction sera �crit dans ce fichier
	extractdestfile=[fichier] : idem pour le r�sum� par extraction
	bothdestfile=[fichier] : idem pour la m�thode hybride
	
idf.txt : contient les mots annot�s pour LexRank. Ce fichier a �t� obtenu avec un dump de wikipedia.
lib/ : contient les librairies requises par le programme
Taggers/ : contient des donn�es requises par l'annoteur POS Stanford

###########
3. Sortie :
###########
Trois fichiers seront cr��s : un pour le r�sum� par abstraction, un par extraction et un pour la m�thode hybride. Si un de ces trois fichiers n'a pas �t� sp�cifi� dans config.txt, il sera cr�� dans le r�pertoire courant.
Si tout se passe bien, les r�sum�s g�n�r�s seront �crits dans ces fichiers. 
Note : au lancement du programme, si un fichier de m�me nom que celui o� on essaye d'�crire existe d�j�, il sera supprim�.
Note 2 : A cause du besoin d'envoyer des requ�tes � un serveur, il est possible que celui-ci ne r�ponde pas. Dans ce cas, un message d'erreur s'affichera sur la console, et le r�sum� ne sera bien entendu pas g�n�r�.